var validation = require('../helper/validation');
var helper = require('../helper/helper');

require('dotenv').config();
var moment = require('moment');
const users = require('../models/user_model');
const product = require('../models/product_model');
const { order, order_return } = require('../models/order_model');
const notification = require('../models/notification_model');
const employee = require('../models/employee_model');
async function placeOrder(req, res) 
{
    try {
        const { customer_name, store_id,phone,sellers,delivery_charges,tax, discount,promo_discount, payment_method,order_detail,shipping_address } = req.body;
        const customer_id = req['user_id'];
        const type = req['type'];
        if (customer_id == null || type == 2 || type == 3) {
            var response = {
                status: 401,
                message: 'customer is un-authorised !'
            };
            return res.status(401).send(response);
        }
        if (store_id != '' || category_id != '' || subcategory_id != '' || total_amount != '')
        {
            const data = {
                customer_id: customer_id,
                customer_name:customer_name,
                phone:phone,
                sellers:sellers,
                store_id: store_id,
                delivery_charges:delivery_charges,
                tax:tax,
                discount: discount,
                promo_discount:promo_discount,
                payment_method: payment_method,
                order_detail:order_detail,
                shipping_address:shipping_address,
            };
            orderResposnse = await order.create(data);
            if (orderResposnse) {
                const empdetail = await employee.findOne({store_id:store_id,role:1})
                const addnotification = {
                    sender_id:customer_id,
                    store_id: store_id,
                    order_id:orderResposnse.order_id,
                    message: 'has placed an order',
                    sender_type:1,
                    receiver_id:empdetail._id,
                }
                const notfication= await notification.create(addnotification);
                var response = {
                    status: 200,
                    message: 'order placed successfully',
                    data: orderResposnse,
                };
                return res.status(200).send(response);
            } else {
                var response = {
                    status: 201,
                    message: 'Unable to add order',
                };
                return res.status(201).send(response);
            }
        } else {
            var response = {
                status: 201,
                message: 'store, category ,subcategory and amount can not be empty',
            };

            return res.status(201).send(response);
        }
    } catch (error) {
        console.log("error", error);
        response = {
            status: 201,
            message: 'Operation was not successful',
        };

        return res.status(201).send(response);
    }
};
async function editorder(req, res) {

    try {
        const customer_id = req['user_id'];
        const type = req['type'];
        if (customer_id == null || type == 2 || type == 3) {
            var response = {
                status: 401,
                message: 'customer is un-authorised !'
            };
            return res.status(401).send(response);
        }
        const {customer_name, store_id,phone,sellers,delivery_charges,tax, discount,promo_discount, payment_method,order_detail,shipping_address, order_id } = req.body;
        const orderRes = await order.findOne({ _id: order_id });
        if (orderRes) {
            const data = {
                customer_id: customer_id,
                customer_name:customer_name,
                phone:phone,
                sellers:sellers,
                store_id: store_id,
                delivery_charges:delivery_charges,
                tax:tax,
                discount: discount,
                promo_discount:promo_discount,
                payment_method: payment_method,
                order_detail:order_detail,
                shipping_address:shipping_address,
            };
            order.findByIdAndUpdate({ _id: order_id },
                { $set: data },
                { new: true },
                async function (err, docs) {
                    if (err) {
                        var response = {
                            status: 201,
                            message: 'order Update failed'
                        };
                        return res.status(201).send(response);
                    }
                    else {
                        const orderData = await order.findOne({ _id: order_id });
                        var response = {
                            status: 200,
                            message: 'order updated successfully',
                            data: orderData,

                        };
                        return res.status(200).send(response);
                    }
                });
        } else {
            var response = {
                status: 201,
                message: 'order not available',
            };

            return res.status(201).send(response);
        }
    } catch (error) {
        console.log("error", error);
        response = {
            status: 201,
            message: 'Operation was not successful',
        };
        return res.status(201).send(response);
    }
};

async function deleteorder(req, res) {
    try {
        const customer_id = req['user_id'];
        const type = req['type'];
        if (customer_id == null || type == 2 || type == 3) {
            var response = {
                status: 401,
                message: 'customer is un-authorised !'
            };
            return res.status(401).send(response);
        }
        const { order_id } = req.body;
        const orderRes = await order.findOne({ _id: order_id });
        if (orderRes) {
            order.findByIdAndDelete({ _id: order_id },
                async function (err, docs) {
                    if (err) {
                        var response = {
                            status: 201,
                            message: 'order delete failed'
                        };
                        return res.status(201).send(response);
                    }
                    else {
                        var response = {
                            status: 200,
                            message: 'order deleted successfully',
                        };
                        return res.status(200).send(response);
                    }
                });
        } else {
            var response = {
                status: 201,
                message: 'order not Available',
            };

            return res.status(201).send(response);
        }
    } catch (error) {
        console.log("error", error);
        response = {
            status: 201,
            message: 'Operation was not successful',
        };
        return res.status(201).send(response);
    }
};

async function orderList(req, res) {
    try {

        const customer_id = req['user_id'];
        const type = req['type'];
        if (customer_id == null || type == 2 || type == 3) {
            var response = {
                status: 401,
                message: 'customer is un-authorised !'
            };
            return res.status(401).send(response);
        }
        var orderdata = await order.find({ customer_id: customer_id })
        var response = {
            status: 200,
            message: 'success',
            data: orderdata,

        };
        return res.status(200).send(response);

    } catch (error) {
        console.log("error", error);
        response = {
            status: 201,
            message: 'Operation was not successful',
        };

        return res.status(201).send(response);
    }
};

async function orderbystatus(req, res) {
    try {

        const vendor_id = req['user_id'];
        const type = req['type'];
        if (vendor_id == null || type == 1 || type == 3) {
            var response = {
                status: 401,
                message: 'vendor is un-authorised !'

            };
            return res.status(401).send(response);
        }
        const { order_status,order_id } = req.body;
        var orderdata = await order.find({ _id: order_id, order_status: order_status })
        var response = {
            status: 200,
            message: 'success',
            data: orderdata,
        };
        return res.status(200).send(response);

    } catch (error) {
        console.log("error", error);
        response = {
            status: 201,
            message: 'Operation was not successful',
        };

        return res.status(201).send(response);
    }
};
async function orderbystore(req, res) {
    try {
        const customer_id = req['user_id'];
        console.log('costomer id',customer_id)
        const type = req['type'];
        if (customer_id == null || type == 2 || type == 3) {
            var response = {
                status: 401,
                message: 'customer is un-authorised !'
            };
            return res.status(401).send(response);
        }
        const { store_id } = req.body;
        var orderdata = await order.find({ store_id: store_id })
        var response = {
            status: 200,
            message: 'success',
            data: orderdata,

        };
        return res.status(200).send(response);

    } catch (error) {
        console.log("error", error);
        response = {
            status: 201,
            message: 'Operation was not successful',
        };

        return res.status(201).send(response);
    }
};

async function orderCancelreturn(req, res) {
    try {
        const { product_name, order_id, price, discounted_price, reason, total, quantity, action } = req.body;
        const customer_id = req['user_id'];
        const type = req['type'];
        if (customer_id == null || type == 2 || type == 3) {
            var response = {
                status: 401,
                message: 'customer is un-authorised !'
            };
            return res.status(401).send(response);
        }
        if (order_id != '') 
        {
            const orderRes = await order.findOne({ _id: order_id });
            
            if (orderRes) {
                const data = {
                    requested_by: customer_id,
                    product_name: product_name,
                    order_id: order_id,
                    price: price,
                    discounted_price: discounted_price,
                    quantity: quantity,
                    total: total,
                    reason: reason,
                    action: action,
                };
                orderResposnse = await order_return.create(data);
                if (orderResposnse) {
                    var response = {
                        status: 200,
                        message: 'Request has send successfully',
                        data: orderResposnse,
                    };
                    return res.status(200).send(response);
                } else {
                    var response = {
                        status: 201,
                        message: 'Unable to cancel/return order',
                    };
                    return res.status(201).send(response);
                }
            } else {
                var response = {
                    status: 201,
                    message: 'order not availabe',
                };
                return res.status(201).send(response);
            }
        } else {
            var response = {
                status: 201,
                message: 'order_id can not be empty',
            };

            return res.status(201).send(response);
        }
    } catch (error) {
        console.log("error", error);
        response = {
            status: 201,
            message: 'Operation was not successful',
        };

        return res.status(201).send(response);
    }
};


module.exports = {
    placeOrder,
    deleteorder,
    editorder,
    orderList,
    orderbystatus,
    orderbystore,
    orderCancelreturn,
};