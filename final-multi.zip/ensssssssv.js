MONGO_URI=mongodb+srv://root:XDSq7NtkCDGk94pb@cluster0.8lpgm.mongodb.net/sk_digi
BASE_URL=file:///home/administrator/Documents/sk_digi/ecommerce_api/upload